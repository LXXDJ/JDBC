package com.ohgiraffers.stock_default.run;

import com.ohgiraffers.stock_default.view.stockMenu;

public class Application {
    public static void main(String[] args) {
        new stockMenu().mainPage();
    }
}
